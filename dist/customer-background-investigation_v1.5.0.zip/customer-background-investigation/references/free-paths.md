# 免费背调路径总表

在快筛或深调中，任何一个问题用常规入口查不到答案时阅读。按"要回答的问题"组织（共 7 个问题），每行都是免费或有免费层级的入口（核验日期 2026-10）。官方登记和制裁入口见 `registries.md`、`screening.md`，此处不重复。

## 问题 1：这家公司真的存在吗？

| 路径 | 入口 | 能看到什么 |
|---|---|---|
| LEI 全球法人识别码 | https://search.gleif.org | 有 LEI 的公司（做过进出口融资、开过信用证的常有）的法定名称、注册地址、母公司；免费、官方 |
| 欧盟商业登记互联 BRIS | https://e-justice.europa.eu/topics/registers-business-insolvency-land/business-registers-search-company-eu_en | 一次检索欧盟各国商业登记，适合不确定在哪国注册时 |
| 美国公司聚合 | https://www.bizapedia.com | 汇总各州登记、负责人、注册代理；再到对应州官方网站复核 |
| 中国大陆关联主体 | https://www.gsxt.gov.cn | 国家企业信用信息公示系统；对方自称有中国母公司、办事处或采购代理时查（境外 IP 可能无法访问） |
| 地图实景 | Google 地图街景、卫星图 | 地址是真实门店、仓库还是住宅、信箱、共享办公 |
| 官方渠道回拨 | 对方官网或登记信息里的电话（不用邮件里给的号码） | 确认"这个人是不是这家公司的员工，这封询盘是不是他发的"——识别冒充最有效的免费办法 |
| 发件人在职与职位 | LinkedIn 搜"姓名 + 公司名"（简称和全名都搜，如 Jim / James）；官网团队页、新闻稿、展会名册 | 是否在职、职位、有没有采购权；公司公开的采购负责人是谁，用来交叉核实 |
| 电话归属 | 北美号码看区号和交换局（前 6 位），其他国家看国家码和区号；官网、登记、地图商家页比对总机 | 总机、直线、手机分别是否与公司所在地一致 |
| 手机号反查 | Truecaller https://www.truecaller.com ，Spokeo、Whitepages 等人员信息聚合网站 | 对方主动提供的手机号登记在谁名下、哪个城市；标"聚合数据，可靠性中等"，报告只写到城市或区域 |
| 签约主体 | 美国州务卿登记里的 DBA（Assumed Name）、邓白氏 DUNS 查询 https://www.dnb.com/duns/duns-lookup.html | 对外品牌背后的法定实体；合同和 PO 抬头用哪个名字 |

## 问题 2：谁在控制这家公司？

| 路径 | 入口 | 能看到什么 |
|---|---|---|
| 英国 PSC 与董事任职 | Companies House 公司页的 People 栏，以及董事姓名页 | 实际控制人；董事同时任职的其他公司（看是否频繁开公司又关公司） |
| 英国取消资格董事 | Companies House 搜索页的 Disqualifications | 该董事是否被禁止担任董事 |
| ICIJ 离岸泄露数据库 | https://offshoreleaks.icij.org | 是否出现在巴拿马文件、潘多拉文件等离岸泄露数据中；出现不等于违法，但需要追问 |
| OpenCorporates 关联 | https://opencorporates.com | 同名董事、同地址的其他公司 |

## 问题 3：这家公司有没有钱、会不会付款？

欧洲多国公开财报免费可查，比付费信用报告更直接：

| 国家 | 入口 | 内容 |
|---|---|---|
| 英国 | Companies House 公司页的 Filing history | 年报（小公司也有资产负债表）、抵押登记（Charges） |
| 德国 | https://www.unternehmensregister.de | 公司年报和财务公告 |
| 法国 | https://www.pappers.fr | 免费汇总 SIREN、董事、已公开的财报、诉讼程序公告 |
| 比利时 | https://consult.cbso.nbb.be | 比利时央行资产负债表中心，免费下载年报 |
| 挪威 | https://www.proff.no | 营收、利润、董事 |
| 瑞典 | https://www.allabolag.se | 营收、利润、董事、信用提示 |
| 英国破产 | https://www.insolvencydirect.bis.gov.uk/eiir/ | 个人破产与债务安排登记（个体经营者、董事个人） |
| 国家风险 | https://www.fatf-gafi.org/en/countries/black-and-grey-lists.html | FATF 反洗钱黑名单和灰名单国家：付款方式至少按 🟡 处理 |
| 国家风险 | https://www.transparency.org/en/cpi | 清廉指数，判断所在国的商业环境风险 |

还可以向对方索要两三家现有供应商的联系方式（贸易参考人），用这些供应商官网上的电话去问"付款是否准时"。这一条免费，而且很有效。

## 问题 4：有没有官司或欺诈记录？

| 路径 | 入口 | 能看到什么 |
|---|---|---|
| 美国联邦案件 | https://dockets.justia.com | 免费检索联邦法院案件目录，作原告还是被告、案由 |
| 英国判决 | https://caselaw.nationalarchives.gov.uk | 英国国家档案馆的判决全文 |
| 美国投诉 | https://www.bbb.org | 商家评级与消费者投诉 |
| 诈骗举报库 | https://www.bbb.org/scamtracker | 按公司名、网址、电话搜索他人举报 |
| 网站信誉 | https://www.scamadviser.com | 网站风险评分、域名年龄、托管位置（只作参考） |

## 问题 5：这封邮件和这个网站是不是假的？

| 路径 | 入口或方法 | 能看到什么 |
|---|---|---|
| 域名核验脚本 | `python3 scripts/domain_check.py --sender <邮箱> --official <官方域名>` | 形似域名、域名年龄、免费邮箱、MX、DMARC，一次输出结论 |
| 证书透明日志 | https://crt.sh | 域名第一次申请 HTTPS 证书的时间，可以佐证网站真正上线的时间 |
| 邮件头 | 让用户在邮箱里"显示原始邮件"，把 Authentication-Results 和 Reply-To 两行存成文件，运行 `domain_check.py --sender <邮箱> --auth-results <文件>` | SPF 或 DKIM 通过且签名域名就是公司域名 → 可以结案；Reply-To 和发件地址不同、SPF/DKIM 显示 fail，都是冒充信号 |
| DMARC 策略 | 脚本输出的 `dmarc_policy`；手工复核用 https://mxtoolbox.com/dmarc.aspx | `reject`/`quarantine` 较难伪造；`none` 或未设置时仍可伪造，必须看邮件头 |
| 邮箱命名规则 | 官网、新闻稿里 2 个以上公开员工邮箱；`domain_check.py --sender-name <姓名> --pattern-samples "姓名:邮箱;…"` | 发件地址是否符合公司格式，只作佐证，不用来推测别人的邮箱 |
| DNS 工具 | https://mxtoolbox.com | 手工复核 MX、SPF、黑名单 |
| 图片反查 | https://tineye.com ，https://lens.google | 官网或社媒上的门店照、团队照、产品图是不是盗用来的 |
| Facebook 主页透明度 | https://www.facebook.com/ads/library ，或主页的"主页透明度"栏 | 主页创建日期、历史名称变更、管理员所在国家 |
| Instagram 账号信息 | 账号主页 → "关于此账号" | 加入日期、历史用户名数量、账号所在国家 |

## 问题 6：付款和单据是不是真的？

| 路径 | 入口 | 能看到什么 |
|---|---|---|
| IBAN 校验 | https://www.iban.com/iban-checker | IBAN 格式是否有效、开户银行和国家，看是否与公司所在国一致 |
| 柜号追踪 | https://www.track-trace.com/container ，或船公司官网 | 对方提供的提单或柜号是否真实存在 |
| 信用证 | 通过自己的开户行核实开证行和 SWIFT 报文 | 不要只看对方发来的 PDF |

## 问题 7：信息匮乏地区怎么查（中东、非洲、南亚、东南亚、拉美）

官方登记查不到或信息很少的时候，用"旁证"拼出一个可信的轮廓：

| 路径 | 入口 | 能证明什么 |
|---|---|---|
| 政府采购中标记录 | 欧盟 https://ted.europa.eu ；英国 https://www.contractsfinder.service.gov.uk ；澳大利亚 https://www.tenders.gov.au ；沙特 https://tenders.etimad.sa ；世界银行项目采购 https://projects.worldbank.org/en/projects-operations/procurement | 公司真实经营，接过政府项目；也能核对对方说的项目是否存在 |
| 商会、行业协会会员名录 | 当地商会官网（如迪拜工商会、各国建材协会、皮草协会） | 会员资格通常要求提交注册文件 |
| 展会参展商名录 | 展会官网的往届参展商名单 | 对方自称"每年参展"是否属实 |
| 地图商家信息 | Google 地图的商家页面 | 开业时长、评价数量、实景照片，和对方说的规模是否相符 |
| WhatsApp Business 资料 | 对方 WhatsApp 的商家资料页 | 商家名称、地址、网站与对方其他信息是否一致 |
| 当地语言检索 | 用阿拉伯语、越南语、印尼语、西班牙语等原文名称搜索 | 英文搜不到的本地新闻、法院公告、招聘信息 |
| 国家海外综合服务平台 | https://hzf.mofcom.gov.cn （国内访问） | 商务部汇集法律、金融、海关、贸促等各类出海服务，可以从这里找到对应国家的服务渠道 |
| 驻外使馆经商处 | 通过商务部网站找到对应国家的经商处 | 可咨询当地商业环境，部分经商处会协助核实企业 |
| 中国贸促会 | https://www.ccpit.org | 商事认证、海外商情、出现贸易纠纷后的调解渠道 |
| 中国信保资信报告 | 通过中国信保官方渠道申请（收费，但比国际信用报告便宜） | 海外买家的资信报告，并可同时申请买方信用限额 |

旁证越多越可信。只有一两条旁证时，维持 🟡，并用自证清单补齐。

## 不花钱的"让对方自证"清单

查不到的信息，直接请对方提供，再自己独立核对：
1. 公司注册证书，或注册号（拿到后自己去官方登记处查）。
2. VAT 或税号（自己用 VIES 或当地税务工具核验）。
3. 公司邮箱发出的正式询盘，并抄送官网上公布的通用邮箱。
4. 视频通话，镜头里能看到门店、仓库或办公室。
5. 两家贸易参考人（现有供应商）的联系方式。
6. 行业专项凭证（如皮草拍卖采购记录），见 `industry/`。

对方愿意配合本身就是一个信号；推脱、催促、只肯用私人账户付款，都应提高相关维度的分数。

## 个人买家（B2C）路径

对方是个人，不是公司：不查商业登记，不做 UBO 和财务分析，也不搜集对方的私人信息（家庭、住址周边人口、种族、收入等）。只回答"这笔交易安不安全"：
1. 制裁筛查：只查姓名。
2. 用域名核验脚本看邮箱：匿名或免费邮箱本身不算风险。
3. 询盘内容是否合理：尺寸、数量、用途是否说得通。
4. 付款：只收有买家保护或可追溯的付款方式，定制件先收定金；拒绝"多付款再退差额"、第三方代付、要求卖方垫付运费。
5. 收货地址：发货前确认完整、可投递。

个人买家只出快筛简报，不出 0–100 分。
